SET NAMES 'utf8';

ALTER TABLE `PREFIX_image_shop` CHANGE `cover` `cover` TINYINT( 1 ) NOT NULL DEFAULT '0';
