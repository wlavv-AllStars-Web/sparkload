SET NAMES 'utf8';

/* PHP:add_module_to_hook(authorizeaim, header); */;
