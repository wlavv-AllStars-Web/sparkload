// https://stackoverflow.com/questions/260857/changing-website-favicon-dynamically

document.querySelector("link[rel~='icon']").href = '/modules/ps_edition_basic/views/favicon.png';
